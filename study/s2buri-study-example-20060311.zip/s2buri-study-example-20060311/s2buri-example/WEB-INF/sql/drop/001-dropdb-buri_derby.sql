DROP TABLE BuriState;
DROP TABLE BuriBranch;
DROP TABLE BuriDataPathHistory;
DROP TABLE BuriData;
DROP TABLE BuriPath;
