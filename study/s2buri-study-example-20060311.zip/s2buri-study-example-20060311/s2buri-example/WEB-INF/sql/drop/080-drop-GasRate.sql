DROP INDEX IdxBillCode;
DROP TABLE MeterCheck;

DROP INDEX IdxCustomerCode;
DROP TABLE Customer;
