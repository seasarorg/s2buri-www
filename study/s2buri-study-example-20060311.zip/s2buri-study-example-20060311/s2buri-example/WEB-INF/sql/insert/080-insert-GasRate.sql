INSERT INTO Customer (customercode, customername, mailaddress) VALUES ('TEST001', '�� ��Y', 'test1@example.com');
INSERT INTO Customer (customercode, customername, mailaddress) VALUES ('TEST002', '�� ���Y', 'test2@example.com');
INSERT INTO Customer (customercode, customername, mailaddress) VALUES ('TEST003', '�� �O�Y', 'test3@example.com');
