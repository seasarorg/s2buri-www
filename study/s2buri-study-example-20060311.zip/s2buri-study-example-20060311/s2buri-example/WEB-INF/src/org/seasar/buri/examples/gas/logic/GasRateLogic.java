package org.seasar.buri.examples.gas.logic;

public interface GasRateLogic {
    int calculate(int usage);
}
