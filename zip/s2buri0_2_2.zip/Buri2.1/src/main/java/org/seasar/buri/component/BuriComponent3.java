/*
 * �쐬��: 2005/06/17
 *
 */
package org.seasar.buri.component;

import java.util.Map;

import org.seasar.buri.common.util.ScriptProcessor;
import org.seasar.buri.xpdl.util.ToolTagSelect;



/**
 * @author makotan
 *
 */
public interface BuriComponent3 {
    public void buriExecute(ScriptProcessor processor,ToolTagSelect tool,Map contextData);

}
