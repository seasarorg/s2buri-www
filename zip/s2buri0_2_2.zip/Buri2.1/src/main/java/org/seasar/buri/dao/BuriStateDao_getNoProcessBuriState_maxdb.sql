SELECT 
	*
FROM 
	BuriState 
WHERE 
	processDate > timestamp
