SELECT 
	*
FROM 
	BuriState 
WHERE 
	pathID = /*pathID*/0 
	and dataID = /*dataID*/0 
order by 
	processDate DESC
