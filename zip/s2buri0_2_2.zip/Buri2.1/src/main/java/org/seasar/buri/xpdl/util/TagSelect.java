/*
 * �쐬��: 2005/06/15
 *
 */
package org.seasar.buri.xpdl.util;

import org.apache.xmlbeans.XmlObject;

/**
 * @author makotan
 *
 */
public interface TagSelect {
    XmlObject getXmlObject();
}
