SELECT 
	*
FROM 
	BuriState 
WHERE 
	pathID = /*pathID*/0 
	and dataID = /*dataID*/0 
	and processDate > CURRENT_TIMESTAMP
