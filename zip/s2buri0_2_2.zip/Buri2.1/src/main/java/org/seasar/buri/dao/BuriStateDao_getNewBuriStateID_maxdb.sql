select BURISTATUSID.nextval 
from dual
;