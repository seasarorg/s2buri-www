select BuriBranchID.nextval 
from dual
;