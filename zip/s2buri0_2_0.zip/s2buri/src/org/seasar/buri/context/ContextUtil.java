/*
 * �쐬��: 2005/10/09
 *
 */
package org.seasar.buri.context;


public interface ContextUtil {
    BuriInnerContext getContext();
    BuriLocalContext getLocalContext();
}
