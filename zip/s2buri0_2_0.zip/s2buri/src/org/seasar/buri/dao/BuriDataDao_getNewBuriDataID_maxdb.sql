select BuriDataID.nextval 
from dual
;