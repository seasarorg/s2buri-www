select count(StateID)
from
	BuriState
where
	PathID = /*PathID*/0
	and DataID in /*pathList*/(0)
