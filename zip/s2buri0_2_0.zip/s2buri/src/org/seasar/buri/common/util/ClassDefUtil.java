/*
 * �쐬��: 2006/01/10
 *
 */
package org.seasar.buri.common.util;

public interface ClassDefUtil {
    String getClassName(Class clazz);
    Class getClazz(Object data);
    String getClassName(Object data);
}
