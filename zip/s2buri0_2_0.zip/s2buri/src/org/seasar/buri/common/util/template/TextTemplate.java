/*
 * �쐬��: 2005/09/13
 *
 */
package org.seasar.buri.common.util.template;

public interface TextTemplate {
    String process(String templateName,Object data);
}
