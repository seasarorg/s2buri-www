INSERT INTO BuriTestMany (
	testID01
	, testID02
	, value
	, versionno
	) 
VALUES (
	/*dto.testID01*/1
	, /*dto.testID02*/2
	, /*dto.value*/'123'
	, /*dto.versionno*/0
)
