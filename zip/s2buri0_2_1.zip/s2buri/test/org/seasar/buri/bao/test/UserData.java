/*
 * �쐬��: 2006/01/06
 *
 */
package org.seasar.buri.bao.test;

public class UserData {
    private String user;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
