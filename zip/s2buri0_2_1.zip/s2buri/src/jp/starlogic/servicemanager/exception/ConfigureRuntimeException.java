/*
 * �쐬��: 2005/12/20
 *
 */
package jp.starlogic.servicemanager.exception;

import org.seasar.framework.exception.SRuntimeException;

public class ConfigureRuntimeException extends SRuntimeException {

    public ConfigureRuntimeException(String arg0) {
        super(arg0);
    }

    /**
     * 
     */
    private static final long serialVersionUID = -8688271525034988667L;

}
