SELECT 
	*
FROM 
	BuriState 
WHERE 
	processDate > CURRENT_TIMESTAMP
