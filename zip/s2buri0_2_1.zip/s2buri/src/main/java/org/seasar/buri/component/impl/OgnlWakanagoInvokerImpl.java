/*
 * �쐬��: 2005/09/04
 *
 */
package org.seasar.buri.component.impl;

import org.seasar.framework.log.Logger;

public class OgnlWakanagoInvokerImpl extends OgnlInvokerImpl {
    private static Logger logger = Logger.getLogger(OgnlWakanagoInvokerImpl.class);

    protected Logger getLogger() {
        return logger;
    }

}
