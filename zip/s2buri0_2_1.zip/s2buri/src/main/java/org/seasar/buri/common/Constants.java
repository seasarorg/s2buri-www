/*
 * �쐬��: 2005/05/15
 *
 */
package org.seasar.buri.common;

/**
 * @author makotan
 *
 */
public class Constants {
    public final static String XPDLQueryPrefix = "declare namespace xpdl = 'http://www.wfmc.org/2002/XPDL1.0'; ";
    public final static int SplitModeXOR = 0;
    public final static int SplitModeAND = 1;
    public final static int JoinModeXOR = 0;
    public final static int JoinModeAND = 1;
}
