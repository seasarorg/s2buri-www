/*
 * 作成日: 2006/07/16
 *
 */
package org.seasar.buri.engine;

import java.util.List;

public interface BuriEngineConfig {
    List getResourceConfigs();
    List getFileConfigs();
}
