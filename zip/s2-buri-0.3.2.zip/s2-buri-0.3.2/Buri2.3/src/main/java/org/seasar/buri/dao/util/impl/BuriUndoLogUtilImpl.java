/*
 * 作成日: 2006/05/16
 *
 */
package org.seasar.buri.dao.util.impl;

import org.seasar.buri.dao.BuriStateUndoLogDao;
import org.seasar.buri.dao.util.BTIDUtil;
import org.seasar.buri.dao.util.BuriUndoLogUtil;

public class BuriUndoLogUtilImpl implements BuriUndoLogUtil {
    
    
    public void addUndoLog(long stateID,long branchID) {
    }


    public BTIDUtil getBtidUtil() {
        return null;
    }


    public void setBtidUtil(BTIDUtil btidUtil) {
    }


    public BuriStateUndoLogDao getUndoDao() {
        return null;
    }


    public void setUndoDao(BuriStateUndoLogDao undoDao) {
    }
    
    
}
