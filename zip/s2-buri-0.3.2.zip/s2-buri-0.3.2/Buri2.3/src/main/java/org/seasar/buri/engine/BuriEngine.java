/*
 * 作成日: 2006/03/26
 *
 */
package org.seasar.buri.engine;

public interface BuriEngine extends WakanagoEngine{
    void setupUserID(BuriSystemContext sysContext);
}
