DROP TABLE FurnitureItem;

DROP SEQUENCE FurnitureItemID;

DROP TABLE BuriTestINT;

DROP SEQUENCE BuriTestINTID;

DROP TABLE BuriTestCHAR ;

DROP TABLE BuriTestMany ;

DROP TABLE BuriTestUser;

DROP SEQUENCE BuriTestUserID;


	