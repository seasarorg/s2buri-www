DROP TABLE FurnitureItem;

DROP TABLE BuriTestINT;

DROP TABLE BuriTestCHAR ;

DROP TABLE BuriTestMany ;

DROP TABLE BuriTestUser;

	