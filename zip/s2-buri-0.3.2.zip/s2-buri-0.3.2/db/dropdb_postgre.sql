drop view BuriPathDataUser;

drop view BuriPathData;

drop view BuriPathHistoryDataUser;

drop view BuriPathHistoryData;


DROP TABLE BuriStateUser;


DROP SEQUENCE BuriStateUserID;

DROP TABLE BuriState;

DROP SEQUENCE BuriStateID;

DROP TABLE BuriStateUndoLog;

DROP SEQUENCE BuriStateUndoLogID;

DROP TABLE BuriTransaction;

DROP SEQUENCE BuriTransactionID;

DROP TABLE BuriBranch;

DROP SEQUENCE BuriBranchID;

DROP TABLE BuriDataPathHistory;

DROP SEQUENCE BuriDataPathHistoryID;

DROP TABLE BuriData;

DROP SEQUENCE BuriDataID;

DROP TABLE BuriPath;

DROP SEQUENCE BuriPathID;

DROP TABLE BuriUser;

DROP SEQUENCE BuriUserID;
