delete from customer;
insert into customer(customerid,customerName) values(nextval('customerid'),'�q1');
insert into customer(customerid,customerName) values(nextval('customerid'),'�q2');
insert into customer(customerid,customerName) values(nextval('customerid'),'�q3');
insert into customer(customerid,customerName) values(nextval('customerid'),'�q4');

delete from item;
insert into item(itemid,itemName,price) values(nextval('itemid'),'PS2',19800);
insert into item(itemid,itemName,price) values(nextval('itemid'),'Wii',29800);
insert into item(itemid,itemName,price) values(nextval('itemid'),'�����_�[�X����',5000);
insert into item(itemid,itemName,price) values(nextval('itemid'),'�Q�[���{�[�C�A�h�o���X',9800);
