package example.org.seasar.buri.web;

public class IndexPage {

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

	public String getLayout() {
		return null;
	}
	
}
