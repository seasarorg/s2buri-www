package example.org.seasar.buri.dao;

import java.util.List;

import org.seasar.dao.annotation.tiger.Arguments;
import org.seasar.dao.annotation.tiger.Query;
import org.seasar.dao.annotation.tiger.S2Dao;

import example.org.seasar.buri.dto.OrderDetailDto;
import example.org.seasar.buri.dto.OrderDetailFindDto;

@S2Dao(bean = OrderDetailDto.class)
public interface OrderDetailDao {

	public List getAllOrderDetail();

	@Query("orderDetailID = ?")
	public OrderDetailDto getOrderDetail(long orderDetailID);

	@Arguments("orderDetailIDs")
	@Query("orderDetailID in /*orderDetailIDs*/(1)")
	public List getOrderDetailByIds(List orderDetailIDs);

	@Arguments("dto,paths")
	public List find(OrderDetailFindDto dto, List paths);

	@Arguments("dto,paths,userIDs")
	public List findAndUser(OrderDetailFindDto dto, List paths, List userIDs);

	@Arguments("orderTitleID")
	@Query("orderTitleID = /*orderTitleID*/0")
	public List getOrderDetailByTitleID(long orderTitleID);

	// public String soleMatch_ARGS = "dto";
	// public OrderDetailDto soleMatch(OrderDetailFindDto dto);

	public void insert(OrderDetailDto dto);

	public void update(OrderDetailDto dto);

	public void delete(OrderDetailDto dto);
}
