package example.org.seasar.buri.web.order;

public class OrderSuccessPage {

	public String initialize() {
		return null;
	}

	public String prerender() {
		return null;
	}

}
