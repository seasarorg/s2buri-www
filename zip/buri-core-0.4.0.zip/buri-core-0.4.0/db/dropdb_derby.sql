DROP VIEW BuriPathDataUser;

DROP VIEW BuriPathData;

DROP VIEW BuriPathHistoryDataUser;

DROP VIEW BuriPathHistoryData;

DROP TABLE BuriStateUser;

DROP TABLE BuriState;

DROP TABLE BuriJoinWaiting;

DROP TABLE BuriStateUndoLog;

DROP TABLE BuriTransaction;

DROP TABLE BuriBranch;

DROP TABLE BuriDataPathHistory;

DROP TABLE BuriData;

DROP TABLE BuriPath;

DROP TABLE BuriUser;
