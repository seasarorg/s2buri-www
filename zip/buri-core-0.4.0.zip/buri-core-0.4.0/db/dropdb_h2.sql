DROP VIEW BuriWaitingPathDataUser;

DROP VIEW BuriWaitingPathData;

DROP VIEW BuriPathDataUser;

DROP VIEW BuriPathData;

DROP SEQUENCE BuriStateUserID;
DROP TABLE BuriStateUser;

DROP SEQUENCE BuriStateID;
DROP TABLE BuriState;

DROP SEQUENCE WaitingUserID;
DROP TABLE BuriWaitingUser;

DROP SEQUENCE BuriWaitingID;
DROP TABLE BuriJoinWaiting;

DROP SEQUENCE BuriStateUndoLogID;
DROP TABLE BuriStateUndoLog;

DROP SEQUENCE BuriTransactionID;
DROP TABLE BuriTransaction;

DROP SEQUENCE BuriBranchID;
DROP TABLE BuriBranch;

DROP SEQUENCE BuriDataPathHistoryID;
DROP TABLE BuriDataPathHistory;

DROP SEQUENCE BuriDataID;
DROP TABLE BuriData;

DROP SEQUENCE BuriPathID;
DROP TABLE BuriPath;

DROP SEQUENCE BuriUserID;
DROP TABLE BuriUser;
