
DROP TABLE Bill;

DROP SEQUENCE BillID;

DROP TABLE ShippingItem;

DROP SEQUENCE ShippingItemID;

DROP TABLE Shipping;

DROP SEQUENCE ShippingID;

DROP TABLE OrderDetail;

DROP SEQUENCE OrderDetailID;

DROP TABLE OrderTitle;

DROP SEQUENCE OrderTitleID;

DROP TABLE Item;

DROP SEQUENCE ItemID;

DROP TABLE Customer;

DROP SEQUENCE CustomerID;
