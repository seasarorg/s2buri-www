DROP TABLE Bill;

DROP INDEX XPKBill;

DROP INDEX XIF4Bill;

DROP INDEX XIF5Bill;

DROP INDEX XIF6Bill;

DROP TABLE ShippingItem;

DROP INDEX XPKShippingItem;

DROP INDEX XIF1ShippingItem;

DROP INDEX XIF2ShippingItem;

DROP TABLE Shipping;

DROP INDEX XPKShipping;

DROP INDEX XIF3Shipping;

DROP INDEX XIF4Shipping;

DROP TABLE OrderDetail;

DROP INDEX XPKOrderDetail;

DROP INDEX XIF3OrderDetail;

DROP INDEX XIF4OrderDetail;

DROP TABLE OrderTitle;

DROP INDEX XPKOrderTitle;

DROP INDEX XIF2OrderTitle;

DROP TABLE Item;

DROP INDEX XPKItem;

DROP TABLE Customer;

DROP INDEX XPKCustomer;
