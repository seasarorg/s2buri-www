DROP SEQUENCE FurnitureItemID;
DROP TABLE FurnitureItem;

DROP SEQUENCE BuriTestINTID;
DROP TABLE BuriTestINT;

DROP TABLE BuriTestCHAR ;

DROP TABLE BuriTestMany ;

DROP SEQUENCE BuriTestUserID;
DROP TABLE BuriTestUser;

	