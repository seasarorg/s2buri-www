/*
 * 作成日: 2006/03/21
 *
 */
package org.escafe.buri.sample.packages.FurnitureManagement;

import org.escafe.buri.util.packages.abst.AbstBuriExePackages;

public class FurnitureManagement extends AbstBuriExePackages{
    
}
