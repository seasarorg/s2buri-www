/*
 * 作成日: 2005/12/31
 *
 */
package org.escafe.buri.bao;

public interface BaoStatusMetadata extends BaoFunctionMetadata {
}
