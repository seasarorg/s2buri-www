/*
 * 作成日: 2006/07/04
 *
 */
package org.escafe.buri.compiler.util.impl.rules;

public abstract class AbstDaoProcRule extends AbstractBuriDataFieldProcRule {

}
