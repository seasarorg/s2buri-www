/*
 * 作成日: 2006/05/16
 *
 */
package org.escafe.buri.dao.util.impl;

import org.escafe.buri.dao.BuriStateUndoLogDao;
import org.escafe.buri.dao.util.BTIDUtil;
import org.escafe.buri.dao.util.BuriUndoLogUtil;

public class BuriUndoLogUtilImpl implements BuriUndoLogUtil {

    public void addUndoLog(long stateID, long branchID) {
    }

    public BTIDUtil getBtidUtil() {
        return null;
    }

    public void setBtidUtil(BTIDUtil btidUtil) {
    }

    public BuriStateUndoLogDao getUndoDao() {
        return null;
    }

    public void setUndoDao(BuriStateUndoLogDao undoDao) {
    }

}
