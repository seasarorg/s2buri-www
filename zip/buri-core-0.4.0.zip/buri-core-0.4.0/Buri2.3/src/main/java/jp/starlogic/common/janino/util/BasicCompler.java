/*
 * 作成日: 2006/05/05
 *
 */
package jp.starlogic.common.janino.util;

public interface BasicCompler {
    Object Compile(BasicCompileInfo info);
}
