/*
 * �쐬��: 2006/03/21
 *
 */
package org.seasar.buri.sample.packages.FurnitureManagement;

import org.seasar.buri.util.packages.abst.AbstBuriExePackages;

public class FurnitureManagement extends AbstBuriExePackages{
    
}
