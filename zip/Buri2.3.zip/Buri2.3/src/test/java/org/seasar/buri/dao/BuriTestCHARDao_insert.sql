INSERT INTO 
	BuriTestCHAR (
	testID
	, value
	, versionno
	) 
VALUES (
	/*dto.testID*/'AAA'
	,/*dto.value*/'123'
	, /*dto.versionno*/0
)