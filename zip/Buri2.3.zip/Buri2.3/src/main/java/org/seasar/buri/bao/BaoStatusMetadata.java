/*
 * �쐬��: 2005/12/31
 *
 */
package org.seasar.buri.bao;

public interface BaoStatusMetadata extends BaoFunctionMetadata{
}
