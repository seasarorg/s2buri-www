/*
 * �쐬��: 2006/05/13
 *
 */
package org.seasar.buri.dao.util.impl;

import org.seasar.buri.dao.util.BTIDUtil;

public class BTIDUtilNoImpl implements BTIDUtil {
    
    public long createBTID() {
        return 0;
    }
    
    public long getCurrentBTID() {
        return 0;
    }
    
    public void setBTID(long btid) {
    }
}
